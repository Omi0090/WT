package com.employee;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/delete")
public class DeleteEmployeeServlet extends HttpServlet {

    // Step 1: Show form if GET is called
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String empIdStr = request.getParameter("emp_id");
        String confirm = request.getParameter("confirm");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (empIdStr != null && "yes".equals(confirm)) {
            // Step 3: Delete the employee
            try {
                int empId = Integer.parseInt(empIdStr);

                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/employee_db", "root", "mysqlom");

                PreparedStatement deleteStmt = con.prepareStatement("DELETE FROM employe WHERE emp_id = ?");
                deleteStmt.setInt(1, empId);
                int rows = deleteStmt.executeUpdate();

                if (rows > 0) {
                    out.println("<h3 style='color:green;'>Employee deleted successfully!</h3>");
                } else {
                    out.println("<h3 style='color:red;'>Employee not found or already deleted.</h3>");
                }

                deleteStmt.close();
                con.close();
            } catch (Exception e) {
                out.println("<h3>Error: " + e.getMessage() + "</h3>");
                e.printStackTrace(out);
            }
        } else {
            // Show form
            response.sendRedirect("deleteEmployee.html");
        }
    }

    // Step 2: Handle POST request to confirm deletion
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String empIdStr = request.getParameter("emp_id");

        if (empIdStr == null || empIdStr.isEmpty()) {
            out.println("<h3 style='color:red;'>Please enter a valid Employee ID.</h3>");
            return;
        }

        try {
            int empId = Integer.parseInt(empIdStr);

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/employee_db", "root", "mysqlom");

            PreparedStatement checkStmt = con.prepareStatement("SELECT * FROM employe WHERE emp_id = ?");
            checkStmt.setInt(1, empId);
            ResultSet rs = checkStmt.executeQuery();

            if (!rs.next()) {
                out.println("<h3 style='color:red;'>Data not found for Employee ID: " + empId + "</h3>");
            } else {
                String empName = rs.getString("first_name") + " " + rs.getString("last_name");

                // Ask for confirmation
                out.println("<script>");
                out.println("if(confirm('Do you want to delete Employee ID: " + empId + " (" + empName + ")?')) {");
                out.println("window.location.href = 'delete?emp_id=" + empId + "&confirm=yes';");
                out.println("} else {");
                out.println("window.location.href = 'deleteEmployee.html';");
                out.println("}");
                out.println("</script>");
            }

            rs.close();
            checkStmt.close();
            con.close();

        } catch (NumberFormatException nfe) {
            out.println("<h3 style='color:red;'>Invalid Employee ID format.</h3>");
        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
            e.printStackTrace(out);
        }
    }
}
